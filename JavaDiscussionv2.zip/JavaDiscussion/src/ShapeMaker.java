import pair.Pair;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class ShapeMaker {
    public static void main(String[] args) {

        ArrayList<Line> allWalls = new ArrayList<Line>();
        allWalls.add(new Line(new Pair (4,10),new Pair(4 ,4)));
        allWalls.add(new Line(new Pair (10, 10), new Pair (7,10)));
        allWalls.add(new Line(new Pair (7,10),new Pair ( 4, 10)));
        allWalls.add(new Line(new Pair (4 ,4),new Pair ( 7,4)));
        allWalls.add(new Line(new Pair (7,4),new Pair ( 10, 4)));
        allWalls.add(new Line(new Pair (10,4),new Pair ( 10, 10)));
        allWalls.add(new Line(new Pair (7,10),new Pair ( 7, 8)));
        allWalls.add(new Line(new Pair (7,6),new Pair ( 7, 8)));
        allWalls.add(new Line(new Pair (7,4),new Pair ( 7, 6)));

        allWalls.add(new Line(new Pair (1,1),new Pair ( 2, 1)));
        allWalls.add(new Line(new Pair (2,1),new Pair ( 2, 2)));
        allWalls.add(new Line(new Pair (2,2),new Pair ( 1, 2)));
        allWalls.add(new Line(new Pair (1,2),new Pair ( 1, 1)));


        //Get All Shapes and largest areas of each
        ArrayList<Double> areas = getShapesAreas(allWalls);
        System.out.println(areas);
    }

    private static ArrayList<Double> getShapesAreas(ArrayList<Line> lines) {
        ArrayList<Double> areas = new ArrayList<>();
        ArrayList<WallTree> wallTrees = new ArrayList<>();
        ArrayList<ArrayList<Pair>> largestLeaves  = new ArrayList<>();
        for(Line line:lines){
            WallTree wallTree = createTree(lines, line);
            ArrayList<WallTree> leaves = getLeaves(wallTree, new ArrayList<WallTree>());
            leaves.removeIf(l ->(!connected(l.rootValue, line)));
            ArrayList<ArrayList<Pair>> lines2 = leavesToLines(leaves);
            largestLeaves.add(getLinesLargestArea(lines2));
            areas.add(getLargestArea(lines2));
        }
        ArrayList<ArrayList<Pair>> largestLeaves2 = (ArrayList<ArrayList<Pair>>)largestLeaves.clone();
        largestLeaves = removeDuplicates(largestLeaves, areas);
        System.out.println(largestLeaves);
        areas = getAreas(largestLeaves);
        return areas;
    }

    private static ArrayList<Double> getAreas(ArrayList<ArrayList<Pair>> largestLeaves) {
        ArrayList<Double> areas = new ArrayList<>();
        for(ArrayList<Pair> leaves :largestLeaves){
           areas.add(getArea(leaves));
        }
        return areas;
    }

    public static ArrayList<ArrayList<Pair>>  removeDuplicates(ArrayList<ArrayList<Pair>> leaves, ArrayList<Double> areas)
    {

        // Create a new ArrayList
        ArrayList<ArrayList<Pair>> newList = new ArrayList<>();

        int x = 0;
        int y = 0;
        boolean add =true;
        // Traverse through the first list
        for (ArrayList<Pair> leaf : leaves) {

            // If this element is not present in newList
            // then add it
           ArrayList<Pair> commonPair =  getCommonPair(leaf, newList);
                if(commonPair != null){//return not null if leave has any common pairs of elements of list
                   //getCommon pairLeaf( to see if the area is greater or equal, if it is , replace

                        if(!(areas.get(x) < areas.get(leaves.indexOf(commonPair))) ){
                            replace(commonPair, newList, leaves.get(x));
                        }
                    add = false;
                }

            if (add ==true) {

                newList.add(leaf);
            }
            x++;
            add = true;
        }

        // return the new list
        return newList;
    }

    private static void replace(ArrayList<Pair> newLeaf, ArrayList<ArrayList<Pair>> leafList, ArrayList<Pair> oldLeaf) {
        leafList.set(leafList.indexOf(newLeaf),oldLeaf);
    }

    private static ArrayList<Pair> getCommonPair(ArrayList<Pair> largestLeaf, ArrayList<ArrayList<Pair>> largestLeaf2) {
        int x = 0;
        for (Pair pair: largestLeaf) {
            for(ArrayList<Pair> leaf : largestLeaf2) {
                if (leaf.contains(pair)) {
                    return leaf;
                }
            }
        }
        return null;
    }

    private static ArrayList<ArrayList<Pair>> leavesToLines(ArrayList<WallTree> leaves) {
        ArrayList<ArrayList<Pair>> lines = new ArrayList<>();
        for(WallTree leaf:leaves){
            lines.add(leafToLines(leaf));
        }
        return lines;
    }

    private static ArrayList<Pair> leafToLines(WallTree leaf) {
        ArrayList<Pair> lines = new ArrayList<>();

        for(int i = 0 ; i<leaf.parents.size()-1;i++){
            if(leaf.parents.get(i).rootValue.start.equals(leaf.parents.get(i+1).rootValue.start)){
                    lines.add(leaf.parents.get(i).rootValue.start);
            }else if(leaf.parents.get(i).rootValue.end.equals(leaf.parents.get(i+1).rootValue.end)) {
                lines.add(leaf.parents.get(i).rootValue.end);

            }else if(leaf.parents.get(i).rootValue.end.equals( leaf.parents.get(i+1).rootValue.start) ){
                lines.add(leaf.parents.get(i).rootValue.end);
            }
            else if(leaf.parents.get(i).rootValue.start.equals(leaf.parents.get(i+1).rootValue.end)) {
                lines.add(leaf.parents.get(i).rootValue.start);
            }
        }

        if(leaf.parents.get(leaf.parents.size()-1).rootValue.start.equals( leaf.rootValue.start) ){
            lines.add(leaf.parents.get(leaf.parents.size()-1).rootValue.start);
            lines.add(leaf.rootValue.end );

        }else if(leaf.parents.get(leaf.parents.size()-1).rootValue.end.equals(leaf.rootValue.end )) {
            lines.add(leaf.parents.get(leaf.parents.size()-1).rootValue.end);
            lines.add(leaf.rootValue.start);
        }else if(leaf.parents.get(leaf.parents.size()-1).rootValue.end.equals(leaf.rootValue.start)) {
            lines.add(leaf.parents.get(leaf.parents.size()-1).rootValue.end);
            lines.add(leaf.rootValue.end);
        }
        else if(leaf.parents.get(leaf.parents.size()-1).rootValue.start.equals(leaf.rootValue.end)) {
            lines.add(leaf.parents.get(leaf.parents.size()-1).rootValue.start);
            lines.add(leaf.rootValue.start );
        }

        return lines;

    }

    public static double getLargestArea(ArrayList<ArrayList<Pair>> leaves){
        double largestArea = 0;
        ArrayList<Double> allAreas = new ArrayList<>();
        for(ArrayList<Pair> leaf: leaves){
            double area = Math.abs(getArea(leaf));
            allAreas.add(area);
            if(area >largestArea){
                largestArea = area;
            }
        }
        return largestArea;
    }
    public static ArrayList<Pair> getLinesLargestArea(ArrayList<ArrayList<Pair>> leaves){
        double largestArea = 0;
        ArrayList<Pair> largestLeaf = new ArrayList<>();
        for(ArrayList<Pair> leaf: leaves){
            double area = getArea(leaf);
            if(area >largestArea){
                largestArea = area;
                largestLeaf = leaf;
            }
        }
        return largestLeaf;
    }

    public static ArrayList<WallTree> getLeaves(WallTree wallTree, ArrayList<WallTree> leaves ){
        if(wallTree.children.size() != 0){

            for(WallTree child: wallTree.children){
                getLeaves(child, leaves);
            }

        }else{
            leaves.add(wallTree);
        }

        return leaves;
    }

    public static WallTree createTree(ArrayList<Line> allWalls, Line startingWall){
        WallTree wallTree = new WallTree(startingWall);
        wallTree.addChild(getLines(wallTree, startingWall, allWalls));

        return wallTree;
    }
    public static ArrayList<WallTree> getLines(WallTree parent, Line startingWall, ArrayList<Line> allWalls){
        ArrayList<WallTree> links = new ArrayList<>();
        boolean child = true;
        for(Line eachWall : allWalls){
            if(isChild(startingWall , eachWall , parent)){
                if(parent.rootValue.start.equals(eachWall.start)){
                    if(parent.pointsVisited.contains(eachWall.start)){
                        child = false;
                    }
                }
                else if(parent.rootValue.start.equals(eachWall.end)){
                    if(parent.pointsVisited.contains(eachWall.end)){
                        child = false;
                    }
                }
                else if(parent.rootValue.end.equals(eachWall.start)){
                    if(parent.pointsVisited.contains(eachWall.start)){
                        child = false;
                    }
                }
                else if(parent.rootValue.end.equals(eachWall.end)){
                    if(parent.pointsVisited.contains(eachWall.start)){
                        child = false;
                    }
                }
                if(child == true){
                    WallTree wallTree = new WallTree(parent , eachWall);

                    links.add(wallTree.setChildren( getLines(wallTree, eachWall, allWalls)));
                }


            }
            child = true;
        }
        if(links.size() == 0){

        }

        return links;
    }

    private static boolean isChild(Line startingWall, Line wall, WallTree parent) {
        if(startingWall.end.equals(new Pair (7,8)) && wall.start.equals(new Pair(7,6))){
            System.out.println("7,8");
        }
        if((wall.start.equals(startingWall.end)) ||
            (startingWall.start.equals(wall.end ))||

          ((wall.start.equals(startingWall.start))&&
                !wall.end.equals(startingWall.end)) ||
          ((wall.end.equals(startingWall.end))&&
                  !(wall.start.equals(startingWall.start )))) {
                        if(!parent.rootValue.equals(wall)){

                            for(WallTree p : parent.parents){
                                if(p.rootValue.equals(wall)){

                                    return false;
                                }
                            }
                            return true;

                        }
                }

        return false;
    }
    public static boolean connected(Line line1, Line line2){
        if((line1.start.equals(line2.end )) ||
                (line2.start.equals(line1.end)) ||
                ((line1.start.equals(line2.start))&&
                        !line1.end.equals( line2.end)) ||
                (line1.end .equals( line2.end) && !line1.start.equals( line2.start))) {
            return true;

        }
        return false;
    }

    public static  double getArea(ArrayList<Pair> leaf){
        double area = 0;//(	 x	1 	 y	2 	−	 y	1 	 x	2 	) 	 	+	 	 (	 x	2 	 y	3 	−	 y	2 	 x	3 	)
       for(int i =0 ; i<leaf.size()-1 ;i++){
           area += leaf.get(i).x * leaf.get(i+1).y - leaf.get(i).y * leaf.get(i+1).x;
       }
        area += leaf.get(leaf.size()-1).x * leaf.get(0).y - leaf.get(leaf.size()-1).y * leaf.get(0).x;
        area = area/2;
        return area;
    }

    //Do algorithm for area
}
