import pair.Pair;

public class Line {
    Pair start;
    Pair end;


    Line(Pair start , Pair end ){
        this.start = start;
        this.end = end;


    }
    public  String toString(){
        return "("+this.start + " ) , ("+this.end+ " )\n";
    }

    @Override
    public boolean equals(Object obj) {

        return ((Line)obj).start.equals(this.start) && ((Line)obj).end.equals(this.end);
    }
}
