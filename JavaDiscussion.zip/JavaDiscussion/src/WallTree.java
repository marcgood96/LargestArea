import pair.Pair;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class WallTree {
    public Line rootValue;
    public ArrayList<WallTree> parents;
    public ArrayList<WallTree> children;
    public ArrayList<Pair> pointsVisited;
    public WallTree(WallTree parent, Line rootData) {
        this.parents =(ArrayList<WallTree>) parent.parents.clone();
        this.parents.add(parent);
        rootValue = rootData;
        children = new ArrayList<WallTree>();
        pointsVisited =(ArrayList<Pair>) parent.pointsVisited.clone();
        if(parent.rootValue.start.equals(this.rootValue.start)){
            pointsVisited.add(this.rootValue.start);
        }
        else if(parent.rootValue.start.equals(this.rootValue.end)){
            pointsVisited.add(this.rootValue.end);
        }
        else if(parent.rootValue.end.equals(this.rootValue.start)){
            pointsVisited.add(this.rootValue.start);
        }
        else if(parent.rootValue.end.equals(this.rootValue.end)){
            pointsVisited.add(this.rootValue.end);
        }
    }
    public WallTree(WallTree parent, Line rootData, ArrayList<WallTree> children) {
        this.parents =(ArrayList<WallTree>) parent.parents.clone();
        this.parents.add(parent);
        rootValue = rootData;
        this.children = children;

        pointsVisited =(ArrayList<Pair>) parent.pointsVisited.clone();
        if(parent.rootValue.start.equals(this.rootValue.start)){
            pointsVisited.add(this.rootValue.start);
        }
        else if(parent.rootValue.start.equals(this.rootValue.end)){
            pointsVisited.add(this.rootValue.end);
        }
        else if(parent.rootValue.end.equals(this.rootValue.start)){
            pointsVisited.add(this.rootValue.start);
        }
        else if(parent.rootValue.end.equals(this.rootValue.end)){
            pointsVisited.add(this.rootValue.end);
        }
    }
    public WallTree(Line rootData) {
        this.parents =  new ArrayList<WallTree>();
        rootValue = rootData;
        children = new ArrayList<WallTree>();
        pointsVisited = new ArrayList<Pair>();
    }


    public void addChild(Line line) {
        this.children.add(new WallTree(line));
    }
    public void addChild(ArrayList<WallTree> lines) {
       this.children = lines;
    }
    public WallTree setChildren(ArrayList<WallTree> lines) {
        this.children = lines;
        return this;
    }
    public String toString(){
        return ""+this.rootValue +" , "+ this.children;
    }


}

