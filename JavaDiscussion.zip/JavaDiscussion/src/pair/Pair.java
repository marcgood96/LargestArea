package pair;

public class Pair {
    public int x ;
    public int y ;
    public Pair(int x , int y){
        this.x = x ;
        this.y = y;
    }
    @Override
    public boolean equals(Object object){


        if (object != null && object instanceof Pair)
        {
            if(((Pair)object).x == this.x && ((Pair)object).y == this.y ){
                return true;
            }else {
                return false;
            }
        }

        return  false;

    }

}

