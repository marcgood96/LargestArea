import pair.Pair;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class ShapeMaker {
    public static void main(String[] args) {

        ArrayList<Line> allWalls = new ArrayList<Line>();
        allWalls.add(new Line(new Pair (4,10),new Pair(4 ,4)));
        allWalls.add(new Line(new Pair (10, 10), new Pair (7,10)));
        allWalls.add(new Line(new Pair (7,10),new Pair ( 4, 10)));
        allWalls.add(new Line(new Pair (4 ,4),new Pair ( 7,4)));
        allWalls.add(new Line(new Pair (7,4),new Pair ( 10, 4)));
        allWalls.add(new Line(new Pair (10,4),new Pair ( 10, 10)));
        allWalls.add(new Line(new Pair (7,10),new Pair ( 7, 8)));
        allWalls.add(new Line(new Pair (7,6),new Pair ( 7, 8)));
        allWalls.add(new Line(new Pair (7,4),new Pair ( 7, 6)));
        LinkedList<Line> linkedLines = linkLines(allWalls);
        double area = getArea(linkedLines);

        WallTree wallTree = createTree(allWalls, allWalls.get(0));


        ArrayList<WallTree> leaves = getLeaves(wallTree, new ArrayList<WallTree>());
        leaves.removeIf(l ->(!connected(l.rootValue, allWalls.get(0))));
        ArrayList<ArrayList<Pair>> lines2 = leavesToLines(leaves);
        lines2.removeIf(l ->(hasDuplicates(l)));
        double newArea = getLargestArea(lines2);

        //Get All Shapes and largest areas of each
        ArrayList<Double> areas = getShapesAreas(allWalls);
    }

    private static boolean hasDuplicates(ArrayList<Pair> l) {
        int x = 0;
        int y = 0;
        for(Pair pair : l){
            for(Pair pair2 : l){
                if(pair.equals(pair2) && x!=y){
                    return true;

                }
                y++;
            }
            y=0;
            x++;
        }
        return false;
    }

    private static ArrayList<Double> getShapesAreas(ArrayList<Line> lines) {
        ArrayList<Double> areas = new ArrayList<>();
        ArrayList<WallTree> wallTrees = new ArrayList<>();
        ArrayList<ArrayList<Pair>> largestLeaves  = new ArrayList<>();
        for(Line line:lines){
            WallTree wallTree = createTree(lines, line);
            ArrayList<WallTree> leaves = getLeaves(wallTree, new ArrayList<WallTree>());
            leaves.removeIf(l ->(!connected(l.rootValue, line)));
            ArrayList<ArrayList<Pair>> lines2 = leavesToLines(leaves);
            largestLeaves.add(getLinesLargestArea(lines2));
            areas.add(getLargestArea(lines2));
        }
        ArrayList<ArrayList<Pair>> largestLeaves2 = (ArrayList<ArrayList<Pair>>)largestLeaves.clone();
        largestLeaves = filterDuplicates(largestLeaves, areas);
        System.out.println(largestLeaves);
        return areas;
    }

    private static ArrayList<ArrayList<Pair>> filterDuplicates(ArrayList<ArrayList<Pair>> largestLeaves, ArrayList<Double> areas) {
        // Go through largest leaves, if pair exists in two ArrayList<Pair> , then remove one will lesser area
        //2 d for loop

        ArrayList<ArrayList<Pair>> newList = new ArrayList<>();
        //Go through list and see if it has a smaller area and has duplicates if it goes through without being smaller , add to list
        int x = 0;
        int y = 0;
        boolean add = true;
       for(ArrayList<Pair> largestLeaf: largestLeaves){
           System.out.println(largestLeaf.contains(new Pair(4,4)));
           add= true;
           for(ArrayList<Pair> largestLeaf2: largestLeaves){
                if(hasCommonPair(largestLeaf, largestLeaf2)){
                    if(!(areas.get(x) >= areas.get(y))){
                        add =false;
                    }
                }
                y++;
           }
           if(add == true){
               newList.add(largestLeaf);
           }
           y=0;
         x++;
       }
       return newList;
    }

    private static boolean hasCommonPair(ArrayList<Pair> largestLeaf, ArrayList<Pair> largestLeaf2) {
        int x = 0;
        for (Pair pair: largestLeaf) {
            if(largestLeaf2.contains(pair) == true){
                return true;
            }
            x++;
        };
        return false;
    }

    private static ArrayList<ArrayList<Pair>> leavesToLines(ArrayList<WallTree> leaves) {
        ArrayList<ArrayList<Pair>> lines = new ArrayList<>();
        for(WallTree leaf:leaves){
            lines.add(leafToLines(leaf));
        }
        return lines;
    }

    private static ArrayList<Pair> leafToLines(WallTree leaf) {
        ArrayList<Pair> lines = new ArrayList<>();

        for(int i = 0 ; i<leaf.parents.size()-1;i++){
            if(leaf.parents.get(i).rootValue.start.equals(leaf.parents.get(i+1).rootValue.start)){
                    lines.add(leaf.parents.get(i).rootValue.start);
            }else if(leaf.parents.get(i).rootValue.end.equals(leaf.parents.get(i+1).rootValue.end)) {
                lines.add(leaf.parents.get(i).rootValue.end);

            }else if(leaf.parents.get(i).rootValue.end.equals( leaf.parents.get(i+1).rootValue.start) ){
                lines.add(leaf.parents.get(i).rootValue.end);
            }
            else if(leaf.parents.get(i).rootValue.start.equals(leaf.parents.get(i+1).rootValue.end)) {
                lines.add(leaf.parents.get(i).rootValue.start);
            }
        }

        if(leaf.parents.get(leaf.parents.size()-1).rootValue.start.equals( leaf.rootValue.start) ){
            lines.add(leaf.parents.get(leaf.parents.size()-1).rootValue.start);
            lines.add(leaf.rootValue.end );

        }else if(leaf.parents.get(leaf.parents.size()-1).rootValue.end.equals(leaf.rootValue.end )) {
            lines.add(leaf.parents.get(leaf.parents.size()-1).rootValue.end);
            lines.add(leaf.rootValue.start);
        }else if(leaf.parents.get(leaf.parents.size()-1).rootValue.end.equals(leaf.rootValue.start)) {
            lines.add(leaf.parents.get(leaf.parents.size()-1).rootValue.end);
            lines.add(leaf.rootValue.end);
        }
        else if(leaf.parents.get(leaf.parents.size()-1).rootValue.start.equals(leaf.rootValue.end)) {
            lines.add(leaf.parents.get(leaf.parents.size()-1).rootValue.start);
            lines.add(leaf.rootValue.start );
        }




        return lines;

    }

    public static double getLargestArea(ArrayList<ArrayList<Pair>> leaves){
        double largestArea = 0;
        for(ArrayList<Pair> leaf: leaves){
            double area = getArea(leaf);
            if(area >largestArea){
                largestArea = area;
            }
        }
        return largestArea;
    }
    public static ArrayList<Pair> getLinesLargestArea(ArrayList<ArrayList<Pair>> leaves){
        double largestArea = 0;
        ArrayList<Pair> largestLeaf = new ArrayList<>();
        for(ArrayList<Pair> leaf: leaves){
            double area = getArea(leaf);
            if(area >largestArea){
                largestArea = area;
                largestLeaf = leaf;
            }
        }
        return largestLeaf;
    }

    public static ArrayList<WallTree> getLeaves(WallTree wallTree, ArrayList<WallTree> leaves ){
        if(wallTree.children.size() != 0){

            for(WallTree child: wallTree.children){
                getLeaves(child, leaves);
            }

        }else{
            leaves.add(wallTree);
        }

        return leaves;
    }

    public static WallTree createTree(ArrayList<Line> allWalls, Line startingWall){
        WallTree wallTree = new WallTree(startingWall);
        wallTree.addChild(getLines(wallTree, startingWall, allWalls));

        return wallTree;
    }
    public static ArrayList<WallTree> getLines(WallTree parent, Line startingWall, ArrayList<Line> allWalls){
        ArrayList<WallTree> links = new ArrayList<>();
        boolean child = true;
        for(Line eachWall : allWalls){
            if(isChild(startingWall , eachWall , parent)){
                if(parent.rootValue.start.equals(eachWall.start)){
                    if(parent.pointsVisited.contains(eachWall.start)){
                        child = false;
                    }
                }
                else if(parent.rootValue.start.equals(eachWall.end)){
                    if(parent.pointsVisited.contains(eachWall.end)){
                        child = false;
                    }
                }
                else if(parent.rootValue.end.equals(eachWall.start)){
                    if(parent.pointsVisited.contains(eachWall.start)){
                        child = false;
                    }
                }
                else if(parent.rootValue.end.equals(eachWall.end)){
                    if(parent.pointsVisited.contains(eachWall.start)){
                        child = false;
                    }
                }
                if(child == true){
                    WallTree wallTree = new WallTree(parent , eachWall);

                    links.add(wallTree.setChildren( getLines(wallTree, eachWall, allWalls)));
                }


            }
        }
        if(links.size() == 0){

        }

        return links;
    }

    private static boolean isChild(Line startingWall, Line wall, WallTree parent) {
        if((wall.start.equals(startingWall.end)) ||
                (startingWall.start.equals(wall.end ))||
          ((wall.start.equals(startingWall.start))&&
                !wall.end.equals(startingWall.end)) ||
          ((wall.end.equals(startingWall.end))&&
                  !(wall.start.equals(startingWall.start )))) {
                        if(!parent.rootValue.equals(wall)){

                            for(WallTree p : parent.parents){
                                if(p.rootValue.equals(wall)){

                                    return false;
                                }
                            }
                            return true;

                        }
                }

        return false;
    }
    public static boolean connected(Line line1, Line line2){
        if((line1.start.equals(line2.end )) ||
                (line2.start.equals(line1.end)) ||
                ((line1.start.equals(line2.start))&&
                        !line1.end.equals( line2.end)) ||
                (line1.end .equals( line2.end) && !line1.start.equals( line2.start))) {
            return true;

        }
        return false;
    }

    public static  double getArea(LinkedList<Line> linkedLines){
        double area = 0;
        for(int i = 0 ; i<linkedLines.size()-1; i++){
            Line line =  linkedLines.get(i);
           area = area + ((line.start.x * line.end.y)-(line.start.y * line.end.x));

        }
        area = area/2;
        return area;
    }
    public static  double getArea(ArrayList<Pair> leaf){
        double area = 0;//(	 x	1 	 y	2 	−	 y	1 	 x	2 	) 	 	+	 	 (	 x	2 	 y	3 	−	 y	2 	 x	3 	)
       for(int i =0 ; i<leaf.size()-1 ;i++){
           area += leaf.get(i).x * leaf.get(i+1).y - leaf.get(i).y * leaf.get(i+1).x;
       }
        area += leaf.get(leaf.size()-1).x * leaf.get(0).y - leaf.get(leaf.size()-1).y * leaf.get(0).x;
        area = area/2;
        return area;
    }

    //First Link Them
    public static LinkedList<Line> linkLines(ArrayList<Line> lines){
        LinkedList<Line> linkedLines = new LinkedList<Line>();

        linkedLines.add(lines.get(0));
        for(int i = 0; i<lines.size(); i++){
            linkedLines.add(getLine(linkedLines.getLast(), lines));
        }

        return linkedLines;
    }
    public static Line getLine(Line line, ArrayList<Line> lines){
        for(Line l : lines){
            if(l.start.equals(line.end)){

                return l;
            }
        }

        return line;
    }
    //Do algorithm for area
}
